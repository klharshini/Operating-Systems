#include "employee.h"
#include <stdlib.h>

Employee::Employee(std::string name, int id, std::string pos, std::string dept, int payrate)
{
    this->id = id;
    this->name = name;
    this->pos = pos;
    this->dept = dept;
    this->payrate = payrate;
    this->noofhours = (rand() % 20) + 20;
    this->salary = noofhours*payrate;
}

bool
Employee::operator == (const Employee & emp)
{ 
    if(this->id == emp.id)
    {
        return true;
    }
    else
    {
        return false;
    }
}

Employee::Employee(std::string name, int id, std::string pos, std::string dept, int payrate, int noofhours, int salary)
{
    this->id = id;
    this->name = name;
    this->pos = pos;
    this->dept = dept;
    this->payrate = payrate;
    this->noofhours = noofhours;
    this->salary = salary;
}

int 
Employee::getID() 
{
    return id;
} 

std::string 
Employee::getname()
{
    return name;
}

std::string 
Employee::getposition()
{
    return pos;
}

std::string 
Employee::getdepartment()
{
    return dept;
}

int 
Employee::getpayrate()
{
    return payrate;
}

int 
Employee::getnoofhours()
{
    return this->noofhours;
}

int 
Employee::getsalarypaycheck()
{
    return this->salary;
} 

void 
Employee::setname(std::string name)
{
    this->name = name;
}

void 
Employee::setposition(std::string pos)
{
    this->pos = pos;
}

void 
Employee::setdepartment(std::string dept)
{
    this->dept = dept;
}

void 
Employee::setpayrate(int payrate)
{
    this->payrate = payrate;
}