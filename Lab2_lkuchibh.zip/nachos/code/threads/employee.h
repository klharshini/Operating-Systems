#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include <stdlib.h>

class Employee
{
    public:
        Employee(std::string name, int id, std::string pos, std::string dept, int payrate);
        bool operator == (const Employee &emp);
        Employee(std::string name, int id, std::string pos, std::string dept, int payrate, int noofhours, int salary);
        int getID();
        std::string getname();
        void setname(std::string name);
        std::string getposition();
        void setposition(std::string pos);
        std::string getdepartment();
        void setdepartment(std::string dept);
        int getpayrate();
        void setpayrate(int payrate);  
        int getnoofhours();   
        int getsalarypaycheck();  

    private:
        int id;
        std::string name;
        std::string pos;
        std::string dept;
        int payrate;
        int noofhours;
        int salary;
}; 
#endif