/*This file contains the interactive process between the nachos and the employee files.
When nachos -K is run, ThreadTest() gets the control and the Menu is displayed for the user */
//Autor: Lakshmi Harshini Kuchibhotla, SU ID: 230997383, SU email: lkuchibh@syr.edu
#include "main.h"
#include "employee.h"
#include <string>
#include "list.h"
#include <iostream>
#include <sstream>
#include <fstream>

//function converts the integer to the string value.
std::string
Convert_IntTostring(int integer)
{
    std::ostringstream outputss;
    outputss << integer;
    return outputss.str();
}

//function which compares the position of the employees and returns the comparision result
int
SortPosition(Employee* e1,Employee* e2)
{
    int result = (*e1).getposition().compare((*e2).getposition());
    return result;
}

//function which compares the department of the employees and returns the comparision result
int
SortDepartment(Employee* e1,Employee* e2)
{
    int result = (*e1).getdepartment().compare((*e2).getdepartment());
    return result;
}

//function sorts the employees using department and position sort.
int 
SortEmployee(Employee* e1,Employee* e2)
{
    int posresult,deptresult;
    posresult = SortPosition(e1, e2);
    deptresult = SortDepartment(e1, e2);
    if(deptresult != 0)
    {
        return deptresult;
    }
    return posresult;
}

//to print the database - function prints the records of all the employees entried
void 
DisplayRecords(Employee* emp)
{
    cout<<" Name: " << (*emp).getname() << "   |   ID: " << (*emp).getID() << "   |   Position: " << (*emp).getposition()
        << "   |   Department: " << (*emp).getdepartment() << "   |   Payrate: " << (*emp).getpayrate() << endl;
}

//search employee implementation - function searches the employee using the department name and returns true if dept found 
bool
Search_usingDept(SortedList<Employee*> empList, std::string search_dept)
{
    bool deptfound = false;
    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    for(; !itr->IsDone(); itr->Next())
    {
        std::string current_dept = itr->Item()->getdepartment();
        if(current_dept == search_dept)
        {
            DisplayRecords(itr->Item());
            deptfound = true;
        }
    }
    return deptfound;
}

//Searches the employee info using the employee ID - returns true if the ID is found
bool
Search_usingId(SortedList<Employee*> empList, std::string search_id)
{
    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    for(; !itr->IsDone(); itr->Next())
    {
        std::string current_id = Convert_IntTostring(itr->Item()->getID());
        if(current_id == search_id)
        {
            DisplayRecords(itr->Item());
            return true;
        }
    }
    return 0;
}

//Prints the Menu for the Employee Management Database
void
DisplayMenu()
{
    cout<< "1. Enter new record" << endl << "2. Display all employees" << endl 
        << "3. Search employee(s)" << endl << "4. Update employee info" << endl 
        << "5. Delete employee info" << endl << "6. Schedule weekly jobs" << endl 
        << "7. Exit" << endl;
}

//function displays the employees records that are searched using ID or department
void
Display_EmployeeSearched(SortedList<Employee*> empList)
{   
    std::string search_str;
    cout<< endl <<"Enter either Department or Id to search: ";
    cin.clear();
    cin.ignore(1000,'\n');
    std::getline(std::cin, search_str);

    if(!Search_usingId(empList, search_str))
    {
        if(!Search_usingDept(empList, search_str))
        {
            cout<< "Invalid ID or Department"<<endl;
            cout<< "***** No records found *****"<<endl;
        }
    }
}

//function updates the employees info to the new user given inputs by using the unique id. 
void
Update_EmployeeInfo(SortedList<Employee*> empList)
{
    std::string update_id;
    bool Id_found = false;
    cout<< endl <<"Enter Employee Id of your choice to update his info: ";
    cin>> update_id;

    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    for(; !itr->IsDone(); itr->Next())
    {
        std::string current_id = Convert_IntTostring(itr->Item()->getID());
        if(update_id == current_id) 
        {
            Id_found = true;
            int update_option, update_field;
            cout<< "Do you want to update all the fields or a particular field?" << endl;
            cout<< "Enter 1.Update all Fields   2. Particular Field :  ";
            cin>> update_option;
            if (update_option == 1)
            {
                std::string updated_name, updated_pos, updated_dept;
                int updated_payrate;
                cout<< "Enter the updated Name: ";
                cin>> updated_name;
                cout<< "Enter the updated Position(1/2/3/4/5/6: ) ";
                cin>> updated_pos;
                cout<< "Enter the updated Department(1/2/3/4): ";
                cin>> updated_dept;
                itr->Item()->setname(updated_name);
                itr->Item()->setposition(updated_pos);
                itr->Item()->setdepartment(updated_dept);

                cout<< "Enter the updated Payrate: ";
                cin>> updated_payrate;
                if(cin.fail())
                {
                    cout<< "Payrate must be a numerical value." << endl;
                    break;
                }
                itr->Item()->setpayrate(updated_payrate);
                break;
            }
            else if (update_option == 2)
            {
                cout<< "Which field you want to update?" << endl;
                cout<< "1.Name  2.Position  3.Department  4.Payrate: ";
                cin>> update_field;

                switch(update_field)
                {
                    case 1:
                    {
                        std::string updated_name;
                        cout<< "Enter the updated Name: ";
                        cin>> updated_name;
                        itr->Item()->setname(updated_name);
                    }
                    break;
                    case 2:
                    {
                        std::string updated_pos;
                        cout<< "Enter the updated Position: ";
                        cin>> updated_pos;
                        itr->Item()->setposition(updated_pos);
                    }
                    break;
                    case 3:
                    {
                        std::string updated_dept;
                        cout<< "Enter the updated Department: ";
                        cin>> updated_dept;
                        itr->Item()->setdepartment(updated_dept);
                    }
                    break;
                    case 4:
                    {
                        int updated_payrate;
                        cout<< "Enter the updated Payrate: ";
                        cin>> updated_payrate;
                        if(cin.fail())
                        {
                            cout<< "Payrate must be a numerical value." << endl;
                            break;
                        }
                        itr->Item()->setpayrate(updated_payrate);
                    }
                    break;
                    default:
                    {
                        cout<< "It is an invalid option" << endl;                        
                    }
                    break;
                }
            }
            else
            {
                cout<< " ***** Invalid option ***** " << endl;
            }            
        }
    }
    if(!Id_found)
    {
        cout<< "The requested Id does not exist." << endl << "***** Hence no records are updated *****" << endl;
    }
}

//function deletes the corresponding employee records given the correct employee ID
void
Delete_EmployeeInfo(SortedList<Employee*> &empList)
{
    std::string delete_id;
    bool Id_found = false;
    cout<< endl << "Enter an Employee ID to delete his/her record from the database: ";
    cin>> delete_id;

    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    Employee* emp;
    for(; !itr->IsDone(); itr->Next())
    {
        std::string current_id = Convert_IntTostring(itr->Item()->getID());
        if(delete_id == current_id)
        {
            Id_found =  true;
            std::string sure;
            cout<< endl << "This is a confirmation to delete the requested Id."<< endl;
            cout<< "Enter (Y/y) to delete: ";
            cin>> sure;
            
            if(sure == "Y" || sure == "y")
            {
                emp = itr->Item();
                empList.Remove(emp);
            }
            else
            {
                cout<< endl <<"You chose not to delete any record"<< endl;
            }
            
        }
    }
    if(!Id_found)
    {
        cout<< "The requested Id does not exist." << endl << "***** Hence no records are deleted *****" << endl;
    }
}

//compares the paycheck amounts of the employees and returns them in descending order
int 
SalaryCompare(Employee* e1, Employee* e2)
{
    if(e1->getsalarypaycheck() < e2->getsalarypaycheck())
    {
        return 1;
    }
    return -1;
}

/*function generates the paychecks of all the employees after the job is scheduled 
for the week using the number of hours worked and the payrate. 
It also prints the total amount of the paycheck of all the employees*/
void
PayCheckAmount(SortedList<Employee*> empList)
{
    SortedList<Employee*> employeeList(SalaryCompare);
    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    for(; !itr->IsDone(); itr->Next())
    {
        employeeList.Insert(itr->Item());
    }

    int finalamount = 0, Order_no = 1;

    ListIterator<Employee*> *itr1 = new ListIterator<Employee*> (&employeeList);
    for(; !itr1->IsDone(); itr1->Next())
    {
        int amount = itr1->Item()->getsalarypaycheck();
        finalamount += amount;
        cout<< "Order " << Order_no++ <<" |  ID: "<< itr1->Item()->getID() <<"   |   Name: " << itr1->Item()->getname() 
            << "    |   NumberofHours: " << itr1->Item()->getnoofhours() << "   |   PayCheck: " << amount 
            << "   |   Payrate: " << itr1->Item()->getpayrate() << endl;
    }
    cout<< "The total amount of pay check: " << finalamount <<endl;
}

//create employee - takes the input from the user for all the fields to create the employee record
Employee* EmployeeRecord(int id)
{
    std::string empname, empdept, emppos;
    int empid, dept, pos, emppayrate;
    cout<< endl <<"Enter Name: ";
    cin>> empname;
    empid = id;
    bool poschoice = true, deptchoice = true;
    while(poschoice)
    {
        cout<<endl<<"Choose from the mentioned Positions";
        cout<<endl<< "1. Intern | 2. Entry Level | 3. Associate | 4. Senior | 5. Lead | 6.Manager " << endl;
        cout<< "Enter Position(1/2/3/4/5/6): ";
        cin>> pos;
        if (pos == 1)
        {
            emppos = "Intern";
            poschoice = false;
        }
        else if(pos == 2)
        {
            emppos = "Entry Level";
            poschoice = false;
        }
        else if (pos == 3)
        {
            emppos = "Associate";
            poschoice = false;
        }
        else if (pos == 4)
        {
            emppos = "Senior";
            poschoice = false;
        }
        else if (pos == 5)
        {
            emppos = "Lead";
            poschoice = false;
        }
        else if (pos == 6)
        {
            emppos = "Manager";
            poschoice = false;
        }
        else
        {
            cout<<endl<< "Invalid entry! Enter a number from the given positions.";
            poschoice = true;
        }
        cin.clear();
        cin.ignore(10000,'\n');
    }
    while(deptchoice)
    {
        cout<<"1. Administrative | 2. HR | 3. Software Development | 4. Business Analytics " << endl;
        cout<<endl<< "Enter Department(1/2/3/4): ";
        cin>> dept;
        if (dept == 1)
        {
            empdept = "Administrative";
            deptchoice = false;
        }
        else if (dept == 2)
        {
            empdept = "HR";
            deptchoice = false;
        }
        else if (dept == 3)
        {
            empdept = "Software Development";
            deptchoice = false;
        }
        else if (dept == 4)
        {
            empdept = "Business Analytics";
            deptchoice = false;
        }
        else
        {
            cout<< "Invalid entry! Enter a number from the given departments.";
            deptchoice = true;
        }
        cin.clear();
        cin.ignore(10000,'\n');
    }

    cout<< "Enter the payrate for the employee: ";

    cin>> emppayrate;
    cin.clear();
    cin.ignore(10000,'\n');
    Employee *emp = new Employee(empname, empid, emppos, empdept, emppayrate);
    return emp; 
}

//function copies all the employee records and stores it to the employee.dat before exiting the program
void
ConsoleToFile(SortedList<Employee*> empList)
{
    ofstream myfile;
    myfile.open("employee.dat");
    
    ListIterator<Employee*> *itr = new ListIterator<Employee*> (&empList);
    for(; !itr->IsDone(); itr->Next())
    {
        myfile<< itr->Item()->getname() << "," << itr->Item()->getID() << "," << itr->Item()->getposition() 
            << "," << itr->Item()->getdepartment() << "," << itr->Item()->getpayrate() << "," 
            << itr->Item()->getnoofhours() << "," << itr->Item()->getsalarypaycheck() << "," <<endl;
    
    }
    myfile.close();
    while(!empList.IsEmpty())
    {
        Employee* emp = empList.RemoveFront();
        delete emp;
    }
}

//ThreadTest() gets the control and calls all the necessary functions in a corresponding sequence.
void
ThreadTest()
{
    int start_id = 8001;
    int next_id = start_id;

    SortedList<Employee*> employeeList(SortEmployee);
    ifstream filename("employee.dat");
    if(filename)
    {
        std::string database;
        while(std::getline(filename, database))
        {
            std::string delimiter = ",";
            int id, payrate, noofhours, salary, i=0;
            std::string name, pos, dept;
            size_t s = 0;
            std::string fields[7], field;

            while((s = database.find(delimiter)) != std::string::npos)
            {
                field = database.substr(0,s);
                fields[i] = field;
                database.erase(0, s+delimiter.length());
                i++;
            }
            
            name = fields[0];
            id = atoi(fields[1].c_str());
            pos = fields[2];
            dept = fields[3];
            payrate = atoi(fields[4].c_str());
            noofhours = atoi(fields[5].c_str());
            salary = atoi(fields[6].c_str());

            if(id > next_id)
            {
                next_id = id;
            }
            else
            {
                next_id = next_id;
            }
            Employee *emp = new Employee(name, id, pos, dept, payrate, noofhours, salary);
            employeeList.Insert(emp);           
        }
        next_id++;
    }

    cout<< "-------------------Employee Database Management Portal-------------------------" << endl;
    bool exited = false;
    do
    {
        cout<< "    Menu: "<< endl;
        DisplayMenu();
        int option;
        cout<< "Enter your choice of operation: ";
        cin>> option;
        switch(option)
        {
            case 1:
            {
                Employee* emp = EmployeeRecord(next_id++);
                employeeList.Insert(emp);
            }
            break;
            case 2:
            {
                cout<< endl <<"***The employee details from the record***" << endl;
                employeeList.Apply(DisplayRecords);
                cout<< "     ----------------*****------------------     " << endl;
            }
            break;
            case 3:
            {
                Display_EmployeeSearched(employeeList);
                cout<< endl <<"     ----------------*****------------------     " << endl;
            }
            break;
            case 4:
            {
                Update_EmployeeInfo(employeeList);
                cout<< endl <<"     ----------------*****------------------     " << endl;
            }
            break;
            case 5:
            {
                Delete_EmployeeInfo(employeeList);
                cout<< endl <<"     ----------------*****------------------     " << endl;
            }
            break;
            case 6:
            {
                cout<<endl<< "***The employee records after scheduling jobs***" <<endl;
                PayCheckAmount(employeeList);
                cout<< "     ----------------*****------------------     " << endl;
            }
            break;
            case 7:
            {
                ConsoleToFile(employeeList);
                exited = true;
            }
            cout<< endl << "------*****-------Exiting--------*****--------" << endl;
            delete kernel;
            exit(0);
            break;
            default:
                cout<< "Not a valid option" << endl;
                cin.clear();
                cin.ignore(10000,'\n');
            break;
        }

    } while (!exited);
    
}

