/*Author: Lakshmi Harshini Kuchibhotla, SU ID: 230997383, SU Mail: lkuchibh@syr.edu
This is a .cc file which contains the definitions for the member functions declared in .h file*/

//import guest.h
#include "guest.h"
#include <stdlib.h>

//constructor
Guest::Guest(int uniqueid, int roomNumbers, int checkin, int checkout, List<int>& roomsAllotted, std::string guestname, Thread* thread)
:roomsAllotted(roomsAllotted)
{
    this->uniqueid = uniqueid;
    this->roomNumbers = roomNumbers;
    this->checkin = checkin;
    this->checkout = checkout;
    this->guestname = guestname;
    this->thread = thread;
}

//function to get the user id which is sequentially generated starting from 1
int
Guest::getuniqueId()
{
    return uniqueid;
}

//function to get the roomnumbers. roomnumbers are generateed randomly in the range of 5
int
Guest::getroomNumbers()
{
    return roomNumbers;
}        

//guest checkin date - randomly generated
int 
Guest::getCheckIndate()
{
    return checkin;
}

//guest checkout date - randomly generated but this should be later than the checkin date
int 
Guest::getCheckOutdate()
{
    return checkout;
}

//list of allocated rooms - number of rooms requested by guest(generated randomly)
List<int>&
Guest::getAllottedRooms()
{
    return roomsAllotted;
}

//guestname - some random name
std::string
Guest::getguestName()
{
    return guestname;
}

Thread*
Guest::getThread()
{
    return thread;
}

//sets the given allotted rooms - number requested by guest(randomly generated) - rooms assigned by system
void
Guest::setAllottedRooms(List<int>& roomsAllotted)
{
    this->roomsAllotted = roomsAllotted;
}