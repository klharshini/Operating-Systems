/*Author: Lakshmi Harshini Kuchibhotla, SU ID: 230997383, SU Mail: lkuchibh@syr.edu
This file contacins all the functionality and operations*/

#include "guest.h"
#include "kernel.h"
#include "main.h"
#include "thread.h"
#include "list.h"
#include "bitmap.h"
#include <string.h>
#include <sstream>
#include <iostream>
#include <vector>

//Thread* actualthread;
int id = 1;
int Days = 11;
int currentDate = 1;

Bitmap *TotalRooms[17];

SortedList<Guest*> *Stayinglist;
SortedList<Guest*> *Checkingoutlist;
SortedList<Guest*> *Confirmedlist;
SortedList<Guest*> *Discardedlist;

//function to convert an integer to string
std::string 
Convert_IntTostring(int integer) 
{ 
    std::ostringstream outputss; 
    outputss << integer; 
    return outputss.str(); 
}

//funtion sorts the guests by their check-in date
int
SortbyCheckIn(Guest* guest1, Guest* guest2)
{
    if(guest1->getCheckIndate() > guest2->getCheckIndate())
    {
        return 1;
    }
    return -1;
}

//function sorts the guests with respect to checkout dates
int
SortbyCheckOut(Guest* guest1, Guest* guest2)
{
    if(guest1->getCheckOutdate() > guest2->getCheckOutdate())
    {
        return 1;
    }
    return -1;
}

//function to display the list of room numbers allotted to each guest
void 
DisplayRooms(int room)
{
    std::cout << room << endl;
}

//function checks the checkin date of every guest with the current date to move guest to staying
void
GuestCheckinMatched(Guest* guest)
{
    if(guest->getCheckIndate() == currentDate)
    {
        kernel->scheduler->ReadyToRun(guest->getThread());
    }
}

//function checks the checkout date of every guest with current date to discard the guest
void
GuestCheckedOut(Guest* guest)
{
    if(guest->getCheckOutdate() == currentDate)
    {
        kernel->scheduler->ReadyToRun(guest->getThread());
    }
}

//function checks out all the guests who are on staying on the last day(11th day)
void
AllGuestsCheckOut(Guest* guest)
{
    kernel->scheduler->ReadyToRun(guest->getThread());
}

//deletes the guest info who checkout the room
void
DeleteCheckedoutguest(Guest* guest)
{
    delete guest;
}

//After the guest checkedOut, this function makes the rooms available for next guest request
void
CheckedoutRoomsAvailable(int rooms)
{
    TotalRooms[currentDate]->Clear(rooms);
}

//function displays all the available rooms after everyin rooms assigned
void
DisplayvacantRooms(int day)
{
    int i=0;
    while(i < 30)
    {
        if(!TotalRooms[day]-> Test(i))
        {
            std::cout<< i <<", ";
        }
        i++;
    }
}

//Displays the total info-guest id, name, checkin, checkout dates, no.of rooms needed
void
DisplayGuestInfo(Guest* guest)
{
    std::cout <<endl<< "Guest: " << guest->getuniqueId() << "   |   Name: " << guest->getguestName() 
            << "   |   No.of Rooms: " << guest->getroomNumbers() << "   |   Check-in date: " 
            << guest->getCheckIndate() << "   |   Check-out date: " << guest->getCheckOutdate() << endl;
}

//used a bitmap for each day with 30 days. function matches the checkin date of the guest and 
//checks if room available as on that date to allot it for the guests
void
AssignRoomswithDate(int roomNumbers, int uniqueid, Guest* guest)
{
    std::vector<int> rooms;

    // Match for guest Checkin date
    if(TotalRooms[guest->getCheckIndate()] -> NumClear() < roomNumbers)
    {
        std::cout << endl << "Number of rooms requested are not available for the given dates."<<endl;
        std::cout << "Hence Guest_"<< uniqueid<<" is added to the Discarded list"<<endl;
        std::cout <<endl<<"--------------*********---------------"<<endl;
        Discardedlist->Insert(guest);
        kernel->currentThread->Finish();
        return;
    }
    for(int i=0; i<roomNumbers; i++)
    {
        int requestedroom = TotalRooms[guest->getCheckIndate()]-> FindAndSet();
        rooms.push_back(requestedroom);
    }

    //checks if same rooms are available for all the requested days
    for(int i = guest->getCheckIndate()+1; i < guest->getCheckOutdate()+1; i++)
    {
        for(int j=0; j<roomNumbers; j++)
        {
            bool roomvacant;
            roomvacant = !(TotalRooms[i] -> Test(rooms[j]));

            //if same rooms are not available for all days, guest id discarded and he cannot be given the rooms
            if(!roomvacant)
            {
                std::cout << endl << "Number of rooms requested are not available for the given dates."<<endl;
                std::cout << "Hence Guest_"<< uniqueid<<" is added to the Discarded list"<<endl;
                std::cout <<endl<<"--------------*********---------------"<<endl;
                Discardedlist->Insert(guest);

                for(int k=0; k<roomNumbers; k++)
                {
                    TotalRooms[guest->getCheckIndate()] -> Clear(rooms[k]);
                }
                kernel->currentThread->Finish();
                return;
            }
        }
    }

    //if same rooms are available for all the needed days, guest is allotted the rooms
    for(int i = guest->getCheckIndate()+1; i < guest->getCheckOutdate()+1; i++)
    {
        for(int j=0; j<roomNumbers; j++)
        {
            TotalRooms[i] -> Mark(rooms[j]);
        }
    }

    List<int> roomsAllotted;
    for(int i=0; i<roomNumbers; i++)
    {
        roomsAllotted.Append(rooms[i]);
    }
    guest->setAllottedRooms(roomsAllotted);
}

//creates threads for different operations
void 
GuestThread(int number)
{   
    //randomly generating the requestedrooms, checkin and checkout dates.
    int uniqueid = id;
    int requestedRooms = (rand() % 5) + 1;
    int checkinDate = (rand() % (Days - currentDate)) + currentDate;
    int checkoutDate = (rand() % 4) + 1 + checkinDate;
    std::string guestname = "Random_Guest_" + Convert_IntTostring(id);
    List<int> roomsAllotted;
    Guest* guest = new Guest(uniqueid, requestedRooms, checkinDate, checkoutDate, roomsAllotted, guestname, kernel->currentThread);
    id++;
    std::cout<<endl<<"Guest_"<<uniqueid<< " Requested for rooms";
    std::cout<<endl<<"Checking if requested number of rooms are available for guest: "<<endl;
    DisplayGuestInfo(guest);

    AssignRoomswithDate(requestedRooms, uniqueid, guest);

    std::cout<< "The rooms assigned for Guest_"<<uniqueid <<" are "<<endl;
    guest->getAllottedRooms().Apply(DisplayRooms);
    std::cout<< endl;
    std::cout<<endl<< "Rooms available after assigned as on guest checkin date: "<<endl;
    DisplayvacantRooms(checkinDate);
    std::cout<<endl;
    
    //for every current date, checkin date is matched, corresponding guest is moved to the staying list
    if(checkinDate == currentDate)
    {
        std::cout<<endl<< "Guest_"<<uniqueid <<" is added to staying list."<< endl;
        std::cout <<endl<<"--------------*********---------------"<<endl;
        Stayinglist->Insert(guest);
        IntStatus oldLevel = kernel->interrupt->SetLevel(IntOff);
        kernel->currentThread->Sleep(false);
        kernel -> interrupt ->SetLevel(oldLevel);  

        //for every match in current date, checkout date, corresponding guest is removed from staying list
        //and his reserved rooms are made available
        
        std::cout<<endl<< "Guest_"<<uniqueid<< " Checked out." <<endl;
        DisplayGuestInfo(guest);
        std::cout <<endl<<"--------------*********---------------"<<endl;
        Stayinglist->Remove(guest);
        guest->getAllottedRooms().Apply(CheckedoutRoomsAvailable);
        std::cout<<endl<<"Rooms available after Guest_"<<uniqueid<< " Checked out are: "<<endl;
        DisplayvacantRooms(currentDate);
        std::cout<<endl;
        kernel->currentThread->Finish();    
        return;        
        
    }

    //when the guest reserves the rooms for a future date, guest is put to confirmed list
    else
    {
        std::cout<< "Guest_"<<uniqueid <<" is added to the confirmed list."<<endl;
        std::cout <<endl<<"--------------*********---------------"<<endl;
        Confirmedlist->Insert(guest);        
        IntStatus oldLevel = kernel->interrupt->SetLevel(IntOff);
        kernel->currentThread->Sleep(false);
        kernel -> interrupt ->SetLevel(oldLevel);

        //at a particular date, if the checkin date of the guest is matched and the guest 
        //is in confirmed list, guest will be moved to staying list
        if(Confirmedlist->IsInList(guest))
        {
            std::cout <<endl<< "Guest_"<<uniqueid <<" moved from confirmed to staying list and the guest details are:"<<endl;
            DisplayGuestInfo(guest);
            std::cout <<endl<<"--------------*********---------------"<<endl;
            Stayinglist->Insert(guest);
            Confirmedlist->Remove(guest);  
        }

        oldLevel = kernel->interrupt->SetLevel(IntOff);
        kernel->currentThread->Sleep(false);
        kernel -> interrupt ->SetLevel(oldLevel);

        std::cout<<"Following Guest is checked out." << endl;
        DisplayGuestInfo(guest);
        Stayinglist->Remove(guest);
        guest->getAllottedRooms().Apply(CheckedoutRoomsAvailable);
        std::cout<<endl<<"Rooms available after Guest_"<<uniqueid<< " Checked out are: "<<endl;
        DisplayvacantRooms(currentDate);
        std::cout<<endl;
        std::cout <<endl<<"--------------*********---------------"<<endl;
        kernel->currentThread->Finish();            
        
    }
    
}

//function calls the guest thread for multiple operations
void 
ConciergeThread(int number)
{
    std::cout<<endl<<"---------------------------------------------"<<endl;
    std::cout<<endl<<"***** Hotel Reservation Tracker *****"<<endl;
    std::cout<<endl<<"---------------------------------------------"<<endl;
    while(currentDate <= Days)
    {
        std::cout<< endl;
        std::cout<< "***Current date = " << currentDate <<endl;
        std::cout<< endl << "Rooms available as on current date = ";
        DisplayvacantRooms(currentDate);
        std::cout<<endl;
        kernel -> interrupt ->SetLevel(IntOff);
        Stayinglist->Apply(GuestCheckedOut);
        kernel->currentThread->Yield();
        Confirmedlist->Apply(GuestCheckinMatched);
        kernel->currentThread->Yield();
        if(currentDate != Days)
        {
            for(int i=0; i<5; i++)
            {
                Thread *th = new Thread("Guest Thread");
                th->Fork((VoidFunctionPtr) GuestThread, (void*) 1);
            }
            kernel->currentThread->Yield();
        }
        currentDate++;
    }

    std::cout<< endl <<"Day 11 - Check out all the guests from the hotel" <<endl;
    kernel -> interrupt ->SetLevel(IntOff);
    Stayinglist->Apply(AllGuestsCheckOut);
    kernel->currentThread->Yield();

    std::cout<< endl <<"    Tracker Summary" << endl <<"--------------------------------------"<<endl;
    for(int i=1; i<Days+1; i++)
    {
        float dailyVacancy_Rate = ((float)TotalRooms[i] -> NumClear() / (float)30)*100;
        std::cout << endl <<"**** Rates on Day: " << i << " ****" << endl;
        std::cout << endl <<" Vacancy Rate = " << dailyVacancy_Rate <<"\%" <<endl;
        std::cout << "Occupancy Rate = "<< (100-dailyVacancy_Rate) << "\%" <<endl;
    }

    float Granted_Rate = (float)Discardedlist -> NumInList() / (float)50 *100;
    std::cout << endl << "!!!!Total Granted Rate  = " << Granted_Rate << "\% " << endl;

    std::cout<<endl<<"-------------*****End of the Hotal Reservation Tracker*****--------------"<<endl<<endl;
    
    Stayinglist->Apply(DeleteCheckedoutguest);
    Confirmedlist->Apply(DeleteCheckedoutguest);
    Checkingoutlist->Apply(DeleteCheckedoutguest);   
    Discardedlist->Apply(DeleteCheckedoutguest);

    delete Stayinglist;
    delete Confirmedlist;
    delete Checkingoutlist;
    delete Discardedlist;
    
    delete kernel;
    exit(0);
}


//Function gets the control first and calls the conciergeThread when forked
void
ThreadTest()
{
    Stayinglist = new SortedList<Guest*> (SortbyCheckOut);
    Checkingoutlist = new SortedList<Guest*> (SortbyCheckOut);
    Confirmedlist = new SortedList<Guest*> (SortbyCheckIn);
    Discardedlist = new SortedList<Guest*> (SortbyCheckIn);

    for(int i=0; i<17; i++)
    {
        TotalRooms[i] = new Bitmap(30);
    }

    Thread *t = new Thread("Concierge Thread");
    t->Fork((VoidFunctionPtr) ConciergeThread, (void *) 1);

}
