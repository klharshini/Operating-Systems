/*Author: Lakshmi Harshini Kuchibhotla, SU ID: 230997383, SU Mail: lkuchibh@syr.edu
This is a .h file which contains all the declarations of the Guests i.e; info of the 
guests and the getter, setter functions for guest operations*/

#ifndef GUEST_H
#define GUEST_H

#include <string.h>
#include <stdlib.h>
#include "list.h"
#include "thread.h"

class Guest
{
    public:
        Guest(int uniqueid, int roomNumbers, int checkin, int checkout, List<int>& roomsAllotted, std::string guestname, Thread* thread);
        int getuniqueId();
        int getroomNumbers();
        int getCheckIndate();
        int getCheckOutdate();
        List<int>& getAllottedRooms();
        std::string getguestName();
        Thread* getThread();
        void setAllottedRooms(List<int>& roomsAllotted);
    private:
        int uniqueid;
        int roomNumbers;
        int checkin;
        int checkout;
        List<int>& roomsAllotted;
        std::string guestname;
        Thread* thread;
};

#endif //this is to end the preceeding #if. 